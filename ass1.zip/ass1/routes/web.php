<?php

use App\Http\Controllers\BobaController;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where yosu can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/welcome', function () {
    return view('welcome');
});


//Route::get('/boba', [BobaController::class,'index']);
Route::get('/boba', [BobaController::class, 'index']);
Route::get('/about', [BobaController::class, 'about']);